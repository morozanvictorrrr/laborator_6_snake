#pragma once

/**
 * @file point.hpp
 * @brief declaratia clasei Point.
 */

/**
 * @class Point
 * @brief reprezinta un punct pe tabla.
 */
class Point {
public:
    int x, y; ///< Coordonatele punctului.

    Point(int x, int y) : x(x), y(y) {}

    bool operator==(const Point& other) const {
        return x == other.x && y == other.y;
    }
};
