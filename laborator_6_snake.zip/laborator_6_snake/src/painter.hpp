#ifndef PAINTER_HPP
#define PAINTER_HPP

#include <SFML/Graphics.hpp>
#include <vector>
#include <string>
#include "point.hpp"

/**
 * @file painter.hpp
 * @brief declaratia clasei Painter.
 */

class Painter {
private:
    sf::RenderWindow window; ///< Fereastra de desenare.

public:
    Painter(); ///< Constructor pentru Painter.

    void DrawImage(const Point& topLeft, const Point& bottomRight, const std::vector<std::vector<char>>& image); ///< Desenează o imagine.
};

#endif // PAINTER_HPP
