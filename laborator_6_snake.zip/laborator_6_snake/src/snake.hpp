#pragma once

#include <vector>
#include "point.hpp"
#include "direction.hpp"
#include "board.hpp"

/**
 * @file snake.hpp
 * @brief declaratia clasei Snake.
 */

/**
 * @class Snake
 * @brief reprezinta sarpele din joc.
 */
class Snake {
private:
    std::vector<Point> body; ///< Corpul sarpelui.

public:
    Snake(); ///< constructor implicit.

    void Move(Direction dir); ///< muta saerpele într-o direcție.

    void Grow(); ///< creste sarpele.

    const std::vector<Point>& GetBody() const; ///< returneaza corpul sarpelui.

    bool CheckCollision(const Board& board) const; ///< verifcia coliziunea.
};
