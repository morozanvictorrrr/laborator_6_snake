#pragma once

#include "point.hpp"

/**
 * @file apple.hpp
 * @brief declaratia clasei Apple.
 */

/**
 * @class Apple
 * @brief reprezinta un mar in jocul Snake.
 */
class Apple {
private:
    Point position; ///< pozitia marului.

public:
    Apple(); ///< Constructor implicit pentru clasa Apple.

    void SetPosition(const Point& pos); ///< Seteaza pozitia marului.

    Point GetPosition() const; ///< obtine pozitia marului.
};
