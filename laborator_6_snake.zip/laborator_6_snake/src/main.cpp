#include <iostream>
#include "snake.hpp"
#include "apple.hpp"
#include "board.hpp"
#include "painter.hpp"
#include "game.hpp"

int main() {
    Board gameBoard(20, 20);
    Game game(gameBoard);

    Painter painter;
    game.Start(painter);

    return 0;
}
