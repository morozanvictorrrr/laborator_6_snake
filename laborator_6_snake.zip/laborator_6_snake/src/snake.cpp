#include "snake.hpp"

Snake::Snake() {
    body.push_back(Point(5, 5)); // initializare la (5, 5).
}

void Snake::Move(Direction dir) {
    Point head = body.front();
    switch (dir) {
        case Direction::Up: head.y -= 1; break;
        case Direction::Down: head.y += 1; break;
        case Direction::Left: head.x -= 1; break;
        case Direction::Right: head.x += 1; break;
    }
    body.insert(body.begin(), head);
    body.pop_back();
}

void Snake::Grow() {
    body.push_back(body.back());
}

const std::vector<Point>& Snake::GetBody() const {
    return body;
}

bool Snake::CheckCollision(const Board& board) const {
    const Point& head = body.front();
    if (head.x < 0 || head.x >= board.GetWidth() || head.y < 0 || head.y >= board.GetHeight()) {
        return true;
    }

    for (size_t i = 1; i < body.size(); ++i) {
        if (body[i] == head) return true;
    }
    return false;
}
