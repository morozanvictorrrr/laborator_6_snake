#ifndef DIRECTION_HPP
#define DIRECTION_HPP

/**
 * @file direction.hpp
 * @brief Enum pentru directiile de miscare ale sarpelui.
 */

/**
 * @enum Direction
 * @brief Definirea directiilor pentru miscare sarpelui.
 */
enum class Direction {
    Up,    ///< miscare in sus.
    Down,  ///< miscare in jos.
    Left,  ///< miscare la stanga.
    Right  ///< miscare la dreapta.
};

#endif // DIRECTION_HPP
