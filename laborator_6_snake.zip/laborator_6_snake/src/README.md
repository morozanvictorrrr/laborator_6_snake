# Snake Game

## Descriere
Snake Game este un joc clasic in care un sarpe se deplaseaza pe o tabla si colecteaza mere pentru a creste in dimensiune.

## Reguli
1. sarpele se deplaseaza in directia indicata de jucator.
2. Daca sarpele mananca un mar, acesta creste in dimensiune.
3. Jocul se termina daca sarpele se ciocneste cu peretii sau cu propriul corp.

## Instructiuni de construire
1. Rulati `make` pentru a compila proiectul.
2. Rulati `./SnakeGame` pentru a incepe jocul.
3. Pentru teste, folositi `make tests` și `./test_snake`.

## Dependențe
- SFML pentru functionalitati grafice.
