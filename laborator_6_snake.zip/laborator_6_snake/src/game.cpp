#include "game.hpp"
#include "snake.hpp"

Game::Game(const Board& b) : board(b), score(0) {}

void Game::Start(Painter& painter) {
    while (true) {
        HandleInput();
        Update(painter);
        Draw(painter);
    }
}

void Game::Update(Painter& painter) {
    snake.Move(Direction::Right);
    CheckCollision();
}

void Game::Draw(Painter& painter) {
    std::vector<std::vector<char>> image(board.GetHeight(), std::vector<char>(board.GetWidth(), '.'));

    for (const auto& point : snake.GetBody()) {
        image[point.y][point.x] = 'X';
    }

    painter.DrawImage(Point(0, 0), Point(board.GetWidth(), board.GetHeight()), image);
}

void Game::HandleInput() {
    // Cod pentru input de la utilizator
}

void Game::CheckCollision() {
    // Cod pentru verificarea coliziunilor
}
