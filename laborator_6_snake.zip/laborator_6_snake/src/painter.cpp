#include "painter.hpp"

Painter::Painter() : window(sf::VideoMode(800, 600), "Snake Game") {}

void Painter::DrawImage(const Point& topLeft, const Point& bottomRight, const std::vector<std::vector<char>>& image) {
    window.clear();

    for (int i = 0; i < image.size(); ++i) {
        for (int j = 0; j < image[i].size(); ++j) {
            if (image[i][j] == 'X') {
                sf::RectangleShape rectangle(sf::Vector2f(10, 10));
                rectangle.setPosition(topLeft.x + j * 10, topLeft.y + i * 10);
                rectangle.setFillColor(sf::Color::Red);
                window.draw(rectangle);
            }
        }
    }

    window.display();
}
