#ifndef GAME_HPP
#define GAME_HPP

#include "painter.hpp"
#include "board.hpp"
#include "snake.hpp"

/**
 * @file game.hpp
 * @brief declaratia clasei Game.
 */

/**
 * @class Game
 * @brief controleaza logica principala a jocului Snake.
 */
class Game {
private:
    Board board;    ///< Tabla de joc.
    Snake snake;    ///< sarpele.
    int score;      ///< Scorul curent.

public:
    Game(const Board& b); ///< Constructor pentru clasa Game.

    void Start(Painter& painter); ///< incepe jocul.

    void Update(Painter& painter); ///< actualizeaza starea jocului.

    void Draw(Painter& painter); ///< deseneaza pe ecran starea jocului.

    void HandleInput(); ///< gestioneaza input-ul utilizatorului.

    void CheckCollision(); ///< verifca coliziunile.
};

#endif // GAME_HPP
