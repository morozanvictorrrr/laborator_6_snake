#pragma once

/**
 * @file board.hpp
 * @brief declaratia clasei Board.
 */

/**
 * @class Board
 * @brief reprezinta tabla de joc.
 */
class Board {
private:
    int width;  ///< latimea tablei.
    int height; ///< inaltimea tablei.

public:
    Board(int w, int h); ///< Constructor pentru clasa Board.

    int GetWidth() const; ///< obtine latimea tablei.

    int GetHeight() const; ///< obtine inaltimea tablei.
};
