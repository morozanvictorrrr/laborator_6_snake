#include "snake.hpp"
#include "board.hpp"
#include <cassert>

void TestSnakeMovement() {
    Snake snake;
    snake.Move(Direction::Right);
    assert(snake.GetBody().front().x == 6);
}

void TestSnakeCollision() {
    Snake snake;
    Board board(10, 10);
    assert(!snake.CheckCollision(board));
}

int main() {
    TestSnakeMovement();
    TestSnakeCollision();
    return 0;
}
